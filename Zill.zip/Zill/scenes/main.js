window.onload = function() {

    FullWidth = window.innerWidth;
    FullHeight = window.innerHeight; 

    Crafty.init(FullWidth,FullHeight, document.getElementById('canvas'));

    Crafty.load(assetsObj);


    Crafty.enterScene("Splash_scr");


};

Crafty.defineScene("Splash_scr", function()
{

       
     //   var background = Crafty.e('2D, Canvas, scrBack')
	    // .attr({x:0, y:0});

	    Crafty.background('url("assets/back1.png")');

	    Crafty.audio.add('splSound' , 'songs/loading.wav');
	    Crafty.audio.add('splSoundend' , 'songs/loadend.wav');

       Crafty.audio.play('splSound',1,0.5);


	        Crafty.sprite(720,405,"assets/splim1.gif", {Ct:[0,0]});
            var Turn = Crafty.e("2D, DOM, Ct")
            .attr({x:FullWidth/2-360, y:FullHeight/2-202});
 

         var goNext = function()
        
         {
 

            Crafty.audio.play('splSoundend',1,0.5);
            
         	var splashT = Crafty.e('2D, Canvas, splT, SpriteAnimation')
	        .attr({x:FullWidth/2-40, y:FullHeight/2+50})
		    .reel("splashT", 600, [
		    	 [4,0],[3,0],[2,0],[1,0],[0,0]
		    
		    ])
		    .animate("splashT", 0);
        
         
            };
      
           var BeginGonext = Crafty.e("Delay").delay(goNext, 1300, 0);
 
});






 Crafty.defineScene("Infos", function()
   {
       Crafty.background('url("assets/back2.png")');

	        Crafty.sprite(98,102,"assets/caf.png", {Caf:[0,0]});
            var Turn = Crafty.e("2D, DOM, Caf")
            .attr({x:FullWidth/2-49, y:FullHeight/2-51});
       
    });

  Crafty.defineScene("Infos2", function()
   {
       Crafty.background('url("assets/back2.png")');

	        Crafty.sprite(162,39,"assets/shadow.png", {Shadow:[0,0]});
            var Turn = Crafty.e("2D, DOM, Shadow")
            .attr({x:FullWidth/2-81, y:FullHeight/2-19.5});
       
    });




var scene02 = function()
 {Crafty.enterScene('Infos') ; }

 Crafty.e("Delay").delay(scene02, 2800, 0);
var scene03 = function()
 {Crafty.enterScene('Infos2') ; }

 Crafty.e("Delay").delay(scene03, 4000, 0);
