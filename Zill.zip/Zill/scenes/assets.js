var assetsObj = {
    "sprites": {
    	"assets/sp1.png": {
            tile :78.483,
            tileh: 86,
            map: {
                spl1: [0,0],
                splEnd: [14,0],
            
            }
        },//End

        "assets/splText2.png": {
            tile :75.220,
            tileh: 18,
            map: {
                splT: [1,0]
            
            }
        }//End



    }
}